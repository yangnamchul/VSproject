package com.vs.my.Tag.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class TagController {

}
