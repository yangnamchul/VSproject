package com.vs.my.Tag.DAOVO;

import java.util.List;


public interface TagDAO {
	
	public void makeTag(TagVO tv);
	public List<TagVO> getVSSBoard(TagVO tv);
}
