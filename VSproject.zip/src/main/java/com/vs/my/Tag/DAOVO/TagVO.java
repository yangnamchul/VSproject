package com.vs.my.Tag.DAOVO;

public class TagVO {
	private int b_seq;
	private int vss_seq;
	
	public int getB_seq() {
		return b_seq;
	}
	public void setB_seq(int b_seq) {
		this.b_seq = b_seq;
	}
	public int getVss_seq() {
		return vss_seq;
	}
	public void setVss_seq(int vss_seq) {
		this.vss_seq = vss_seq;
	}
	
	
}
