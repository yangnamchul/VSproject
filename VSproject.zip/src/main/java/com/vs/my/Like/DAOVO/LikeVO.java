package com.vs.my.Like.DAOVO;

import java.util.Date;

public class LikeVO {
	private int b_seq;
	private String u_id;
	private int l_like;
	private String l_ip;
	private Date l_date;
	
	public int getB_seq() {
		return b_seq;
	}
	public void setB_seq(int b_seq) {
		this.b_seq = b_seq;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public int getL_like() {
		return l_like;
	}
	public void setL_like(int l_like) {
		this.l_like = l_like;
	}
	public String getL_ip() {
		return l_ip;
	}
	public void setL_ip(String l_ip) {
		this.l_ip = l_ip;
	}
	public Date getL_date() {
		return l_date;
	}
	public void setL_date(Date l_date) {
		this.l_date = l_date;
	}
	
	
	
	
}
