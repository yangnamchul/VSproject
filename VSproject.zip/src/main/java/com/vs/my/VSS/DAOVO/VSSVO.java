package com.vs.my.VSS.DAOVO;

public class VSSVO {
	private int vss_seq;
	private String vss_name;
	private String vss_content;
	
	public int getVSS_seq() {
		return vss_seq;
	}
	public void setVSS_seq(int vSS_seq) {
		vss_seq = vSS_seq;
	}
	public String getVSS_name() {
		return vss_name;
	}
	public void setVSS_name(String vSS_name) {
		vss_name = vSS_name;
	}
	public String getVSS_content() {
		return vss_content;
	}
	public void setVSS_content(String vSS_content) {
		vss_content = vSS_content;
	}
	
	
}
